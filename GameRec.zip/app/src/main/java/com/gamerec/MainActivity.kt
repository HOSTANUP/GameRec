package com.gamerec

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("gr", Context.MODE_PRIVATE) }
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var btn: Button
    private lateinit var rgO: RadioGroup
    private lateinit var rgQ: RadioGroup
    private lateinit var rgC: RadioGroup
    private val idLand = View.generateViewId()
    private val idPort = View.generateViewId()
    private val idSaver = View.generateViewId()
    private val idHd = View.generateViewId()
    private val id60 = View.generateViewId()
    private val idAvc = View.generateViewId()
    private val idHevc = View.generateViewId()
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 16f; setPadding(0, pad, 0, 0)
        }
        fun radio(i: Int, t: String) = RadioButton(this).apply {
            id = i; text = t; setTextColor(Color.WHITE)
        }

        status = label("")
        val pick = Button(this).apply {
            text = "SD card folder chuno"
            setOnClickListener { pickFolder() }
        }
        rgO = RadioGroup(this).apply {
            addView(radio(idLand, "Landscape (game)"))
            addView(radio(idPort, "Portrait"))
            check(if (prefs.getBoolean("land", true)) idLand else idPort)
        }
        rgQ = RadioGroup(this).apply {
            addView(radio(idSaver, "Best - 576p, 30 FPS"))
            addView(radio(idHd, "720p, 30 FPS"))
            addView(radio(id60, "60 FPS - 576p"))
            check(when (prefs.getInt("q", 0)) { 1 -> idHd; 2 -> id60; else -> idSaver })
        }
        rgC = RadioGroup(this).apply {
            addView(radio(idHevc, "H.265 (best quality, recommended)"))
            addView(radio(idAvc, "H.264 (safe)"))
            check(if (prefs.getBoolean("hevc", true)) idHevc else idAvc)
        }
        btn = Button(this).apply {
            textSize = 20f
            setOnClickListener { onBtn() }
        }

        root.addView(status)
        root.addView(pick)
        root.addView(label("Orientation"))
        root.addView(rgO)
        root.addView(label("Quality (sab 4.5 Mbps, ~520 MB / 15 min)"))
        root.addView(rgQ)
        root.addView(label("Codec"))
        root.addView(rgC)
        root.addView(label(""))
        root.addView(btn)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#121212"))
            addView(root)
        })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun pickFolder() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            ), 1
        )
    }

    private fun onBtn() {
        if (RecState.running) {
            startService(Intent(this, RecService::class.java).setAction(RecService.ACTION_STOP))
            return
        }
        begin()
    }

    private fun begin() {
        if (prefs.getString("tree", null) == null) {
            Toast.makeText(this, "Pehle SD card folder chuno", Toast.LENGTH_LONG).show(); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 3); return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 3 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) begin()
        else Toast.makeText(this, "Audio permission chahiye (game sound ke liye)", Toast.LENGTH_LONG).show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        if (req == 1) {
            val uri: Uri = data.data ?: return
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            prefs.edit().putString("tree", uri.toString()).apply()
        } else if (req == 2) {
            val land = rgO.checkedRadioButtonId == idLand
            val q = when (rgQ.checkedRadioButtonId) { idHd -> 1; id60 -> 2; else -> 0 }
            val fps = if (q == 2) 60 else 30
            val bitrate = 4_500_000
            val shortSide = if (q == 1) 720 else 576
            val hevc = rgC.checkedRadioButtonId == idHevc
            prefs.edit().putBoolean("land", land).putInt("q", q).putBoolean("hevc", hevc).apply()
            startForegroundService(
                Intent(this, RecService::class.java)
                    .putExtra("code", res).putExtra("data", data)
                    .putExtra("land", land).putExtra("fps", fps)
                    .putExtra("bitrate", bitrate).putExtra("short", shortSide).putExtra("hevc", hevc)
            )
            Toast.makeText(this, "Recording shuru - ab game kholo", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    private fun refresh() {
        val t = prefs.getString("tree", null)
        val folder = t?.let { Uri.parse(it).lastPathSegment ?: it } ?: "(chuna nahi)"
        btn.text = if (RecState.running) "STOP" else "START RECORDING"
        status.text = "SD folder: $folder\n" +
            (if (RecState.running) "Recording chal rahi hai..." else "Ready") +
            (RecState.last?.let { "\nLast saved: $it" } ?: "") +
            (RecState.error?.let { "\nError: $it" } ?: "")
    }
}
