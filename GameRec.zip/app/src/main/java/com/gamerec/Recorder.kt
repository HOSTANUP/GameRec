package com.gamerec

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.util.DisplayMetrics
import android.view.Display
import java.io.IOException
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

internal class Item(val video: Boolean, val fmt: MediaFormat?, val data: ByteArray?, val pts: Long, val flags: Int)

/** Writes encoded samples to the muxer on its own thread, so a slow SD card never blocks the encoders. */
internal class MuxThread(private val m: MediaMuxer, private val hasAudio: Boolean) : Thread("mux") {
    private val q = LinkedBlockingQueue<Item>()
    private val stopItem = Item(true, null, null, 0, 0)

    fun format(video: Boolean, f: MediaFormat) { q.put(Item(video, f, null, 0, 0)) }

    fun sample(video: Boolean, b: ByteBuffer, off: Int, size: Int, pts: Long, flags: Int) {
        val arr = ByteArray(size)
        b.position(off); b.limit(off + size); b.get(arr)
        q.put(Item(video, null, arr, pts, flags))
    }

    fun finish() { q.put(stopItem) }

    override fun run() {
        var vt = -1
        var at = -1
        var started = false
        val pending = ArrayList<Item>()
        val info = MediaCodec.BufferInfo()
        fun write(item: Item) {
            try {
                val d = item.data!!
                info.set(0, d.size, item.pts, item.flags)
                m.writeSampleData(if (item.video) vt else at, ByteBuffer.wrap(d), info)
            } catch (e: Exception) { }
        }
        try {
            while (true) {
                val item = q.take()
                if (item === stopItem) break
                if (item.fmt != null) {
                    if (item.video) vt = m.addTrack(item.fmt) else at = m.addTrack(item.fmt)
                    if (!started && vt >= 0 && (!hasAudio || at >= 0)) {
                        m.start(); started = true
                        pending.forEach { write(it) }
                        pending.clear()
                    }
                } else if (started) write(item) else pending.add(item)
            }
        } catch (e: Exception) { }
        try { if (started) m.stop() } catch (e: Exception) { }
        try { m.release() } catch (e: Exception) { }
    }
}

class Recorder(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val treeUri: Uri,
    private val landscape: Boolean,
    private val fps: Int,
    private val bitrate: Int,
    private val hevc: Boolean,
    private val onDone: () -> Unit
) {
    private val baseUs = System.nanoTime() / 1000
    @Volatile private var stopping = false
    private var fileName = ""
    private var pfd: ParcelFileDescriptor? = null
    private var mux: MuxThread? = null
    private var vEnc: MediaCodec? = null
    private var aEnc: MediaCodec? = null
    private var aRec: AudioRecord? = null
    private var vDisplay: VirtualDisplay? = null
    private var vThread: Thread? = null
    private var aThread: Thread? = null

    fun start() {
        try { doStart() } catch (e: Exception) { stopping = true; cleanup(); throw e }
    }

    private fun doStart() {
        // --- size: short side 720, multiples of 16 ---
        val dm = DisplayMetrics()
        val disp = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        disp.getRealMetrics(dm)
        val a = max(dm.widthPixels, dm.heightPixels).toFloat()
        val b = min(dm.widthPixels, dm.heightPixels).toFloat()
        val sc = min(1f, 720f / b)
        val longS = ((a * sc) / 16f).roundToInt() * 16
        val shortS = ((b * sc) / 16f).roundToInt() * 16
        val w = if (landscape) longS else shortS
        val h = if (landscape) shortS else longS

        // --- output file on SD card (SAF) ---
        val resolver = ctx.contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
        fileName = "REC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val doc = DocumentsContract.createDocument(resolver, parent, "video/mp4", fileName)
            ?: throw IOException("SD card me file nahi bani")
        val p = resolver.openFileDescriptor(doc, "rw") ?: throw IOException("SD card file open nahi hui")
        pfd = p

        // --- game audio (internal playback capture, no mic) ---
        var hasAudio = false
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val af = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord.Builder()
                .setAudioFormat(af)
                .setBufferSizeInBytes(max(minBuf * 4, 32768))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); throw IllegalStateException() }
            val af2 = MediaFormat.createAudioFormat("audio/mp4a-latm", 44100, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val ae = MediaCodec.createEncoderByType("audio/mp4a-latm")
            ae.configure(af2, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            ae.start()
            aRec = rec; aEnc = ae; hasAudio = true
        } catch (e: Exception) {
            hasAudio = false
        }

        val mx = MuxThread(MediaMuxer(p.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), hasAudio)
        mux = mx
        mx.start()

        // --- video encoder (hardware H.264, surface input = zero copy) ---
        val hevcName = if (hevc) MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull { ci ->
            ci.isEncoder && ci.isHardwareAccelerated && ci.supportedTypes.any { it.equals("video/hevc", true) }
        }?.name else null
        fun buildEnc(mime: String, name: String?, br: Int): MediaCodec {
            val vf = MediaFormat.createVideoFormat(mime, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, br)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
                setInteger("max-fps-to-encoder", fps)
            }
            val c = if (name != null) MediaCodec.createByCodecName(name) else MediaCodec.createEncoderByType(mime)
            try {
                c.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            } catch (e: Exception) { c.release(); throw e }
            return c
        }
        val ve = try {
            if (hevcName != null) buildEnc("video/hevc", hevcName, (bitrate * 0.6).toInt())
            else buildEnc("video/avc", null, bitrate)
        } catch (e: Exception) {
            buildEnc("video/avc", null, bitrate)
        }
        val surface = ve.createInputSurface()
        ve.start()
        vEnc = ve

        // --- drain threads ---
        vThread = thread(name = "vdrain") {
            val info = MediaCodec.BufferInfo()
            var last = -1L
            try {
                while (true) {
                    val i = ve.dequeueOutputBuffer(info, 10_000)
                    if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        mx.format(true, ve.outputFormat)
                    } else if (i >= 0) {
                        val buf = ve.getOutputBuffer(i)
                        if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            var pts = info.presentationTimeUs - baseUs
                            if (pts < 0) pts = 0
                            if (pts <= last) pts = last + 1
                            last = pts
                            mx.sample(true, buf, info.offset, info.size, pts, info.flags)
                        }
                        ve.releaseOutputBuffer(i, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            } catch (e: Exception) { }
        }

        if (hasAudio) {
            val rec = aRec!!
            val enc = aEnc!!
            aThread = thread(name = "adrain") {
                val pcm = ByteArray(4096)
                val info = MediaCodec.BufferInfo()
                var frames = 0L
                var startUs = -1L
                var last = -1L
                fun drain(): Boolean {
                    while (true) {
                        val i = enc.dequeueOutputBuffer(info, 0)
                        if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { mx.format(false, enc.outputFormat); continue }
                        if (i < 0) return false
                        val buf = enc.getOutputBuffer(i)
                        if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            var pts = info.presentationTimeUs
                            if (pts <= last) pts = last + 1
                            last = pts
                            mx.sample(false, buf, info.offset, info.size, pts, info.flags)
                        }
                        enc.releaseOutputBuffer(i, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                    }
                }
                try {
                    rec.startRecording()
                    while (!stopping) {
                        val n = rec.read(pcm, 0, pcm.size)
                        if (n < 0) break
                        if (n == 0) continue
                        if (startUs < 0) startUs = System.nanoTime() / 1000 - baseUs
                        val idx = enc.dequeueInputBuffer(10_000)
                        if (idx >= 0) {
                            val ib = enc.getInputBuffer(idx)!!
                            ib.clear(); ib.put(pcm, 0, n)
                            enc.queueInputBuffer(idx, 0, n, startUs + frames * 1_000_000L / 44100, 0)
                            frames += n / 4
                        }
                        drain()
                    }
                    rec.stop()
                    val endPts = max(startUs, 0L) + frames * 1_000_000L / 44100
                    var tries = 0
                    while (tries++ < 300) {
                        val idx = enc.dequeueInputBuffer(10_000)
                        if (idx >= 0) {
                            enc.queueInputBuffer(idx, 0, 0, endPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            break
                        }
                        drain()
                    }
                    tries = 0
                    while (tries++ < 300 && !drain()) Thread.sleep(5)
                } catch (e: Exception) { }
            }
        }

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stop() }
        }, Handler(Looper.getMainLooper()))
        vDisplay = projection.createVirtualDisplay(
            "GameRec", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null
        )
    }

    @Synchronized
    fun stop() {
        if (stopping) return
        stopping = true
        thread(name = "stopper") {
            try { vDisplay?.release() } catch (e: Exception) { }
            try { vEnc?.signalEndOfInputStream() } catch (e: Exception) { }
            try { vThread?.join(4000) } catch (e: Exception) { }
            try { aThread?.join(4000) } catch (e: Exception) { }
            mux?.finish()
            try { mux?.join(15000) } catch (e: Exception) { }
            cleanup()
            RecState.last = fileName
            RecState.running = false
            try { projection.stop() } catch (e: Exception) { }
            onDone()
        }
    }

    private fun cleanup() {
        try { vDisplay?.release() } catch (e: Exception) { }
        try { vEnc?.stop() } catch (e: Exception) { }
        try { vEnc?.release() } catch (e: Exception) { }
        try { aEnc?.stop() } catch (e: Exception) { }
        try { aEnc?.release() } catch (e: Exception) { }
        try { aRec?.release() } catch (e: Exception) { }
        try { pfd?.close() } catch (e: Exception) { }
    }
}
