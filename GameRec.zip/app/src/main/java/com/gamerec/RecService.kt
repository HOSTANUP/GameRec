package com.gamerec

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class RecService : Service() {
    companion object {
        const val ACTION_STOP = "com.gamerec.STOP"
        const val CH = "rec"
    }

    private var rec: Recorder? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            val r = rec
            if (r != null) r.stop() else stopSelf()
            return START_NOT_STICKY
        }
        if (rec != null || intent == null) return START_NOT_STICKY

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Recording", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, RecService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("GameRec - recording chal rahi hai")
            .setContentText("Band karne ke liye STOP dabao")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stopPi)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        RecState.error = null
        try {
            val code = intent.getIntExtra("code", 0)
            val data = intent.getParcelableExtra<Intent>("data")!!
            val land = intent.getBooleanExtra("land", true)
            val fps = intent.getIntExtra("fps", 30)
            val bitrate = intent.getIntExtra("bitrate", 4_000_000)
            val hevc = intent.getBooleanExtra("hevc", true)
            val shortSide = intent.getIntExtra("short", 576)
            val tree = Uri.parse(getSharedPreferences("gr", MODE_PRIVATE).getString("tree", null)!!)
            val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            val r = Recorder(this, proj, tree, land, fps, bitrate, hevc, shortSide) {
                Handler(Looper.getMainLooper()).post {
                    stopForeground(true)
                    stopSelf()
                }
            }
            r.start()
            rec = r
            RecState.running = true
        } catch (e: Exception) {
            RecState.error = e.message ?: e.toString()
            RecState.running = false
            stopForeground(true)
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
