package com.gamerec

object RecState {
    @Volatile var running = false
    @Volatile var last: String? = null
    @Volatile var error: String? = null
}
