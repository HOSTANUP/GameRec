plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gamerec"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gamerec"
        minSdk = 29
        targetSdk = 30
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        create("rel") {
            storeFile = file("gamerec.keystore")
            storePassword = "gamerec123"
            keyAlias = "gamerec"
            keyPassword = "gamerec123"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("rel")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
